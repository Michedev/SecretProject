class EndpointRequests:

    def __init__(self, numRequests, videoID, endpointID):
        self.numRequests = numRequests
        self.videoID = videoID
        self.endpointID = endpointID