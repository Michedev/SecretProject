class CacheServer:

    def __init__(self, id, latency):
        self.id = id
        self.latency = latency
