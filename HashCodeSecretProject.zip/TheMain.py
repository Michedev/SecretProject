from Logic import Brain

theBrain = Brain('me_at_the_zoo.in', 'Output/me_at_the_zoo.out')
theBrain.run()
theBrain = Brain('trending_today.in', 'Output/trending_today.out')
theBrain.run()
theBrain = Brain('videos_worth_spreading.in', 'Output/videos_worth_spreading.out')
theBrain.run()
theBrain = Brain('kittens.in', 'Output/kittens.out')
theBrain.run()